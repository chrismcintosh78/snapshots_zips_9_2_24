document.addEventListener('DOMContentLoaded', function () {
    const icons = [
        { id: '#icon1', class: 'bi-pc', message: "Need PC/Mac Support?" },
        { id: '#icon2', class: 'bi-wifi', message: "Need Network Consulting?" },
        { id: '#icon3', class: 'bi-phone', message: "Need Full-Stack or Android App Development?" },
    ];

    let pitchText = document.getElementById('pitchText');

    icons.forEach((icon, index) => {
        document.querySelector(icon.id).classList.add(icon.class);
        anime({
            targets: icon.id,
            opacity: [0, 1],
            translateY: [-50, 0],
            easing: 'easeOutExpo',
            duration: 2000,
            delay: index * 5000,
            complete: function() {
                pitchText.textContent = icon.message;
            }
        });
    });

    anime({
        targets: '.hero',
        duration: 15000,
        easing: 'linear',
        complete: function() {
            pitchText.textContent = "Let's work together!";
        }
    });
});
