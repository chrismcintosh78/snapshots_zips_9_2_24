<?php
// PHP to get the URL path and route content
function routeRequest() {
    $urlPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $pathParts = explode('/views/', $urlPath);

    if (isset($pathParts[1])) {
        $viewPath = $pathParts[1];

        // Route based on the viewPath
        switch ($viewPath) {
            case 'Home':
                // Load Home view
                loadView('Home');
                break;
            case 'Contact':
                // Load Contact view
                loadView('Contact');
                break;
            // Add more cases as needed
            default:
                // Load a default view or show a 404 page
                loadView('404');
                break;
        }
    } else {
        // Load a default view or show a 404 page
        loadView('404');
    }
}

function loadView($view) {
    // Logic to load the view content
    $viewFile = __DIR__ . "/../app/views/{$view}.php";
    if (file_exists($viewFile)) {
        include $viewFile;
    } else {
        echo "View not found: {$view}";
    }
}

// Call the routeRequest function to handle the routing
routeRequest();
?>