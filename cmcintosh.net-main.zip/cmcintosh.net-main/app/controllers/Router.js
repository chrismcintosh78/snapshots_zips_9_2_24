// JavaScript to get the URL path and route content
"use strict";
document.addEventListener("DOMContentLoaded", function() {
    const url = new URL(window.location.href);
    const path = url.pathname;

    // Extract the part after '/views/'
    const viewPath = path.split('/views/')[1];

    if (viewPath) {
        // Route based on the viewPath
        switch (viewPath) {
            case 'Home':
                // Load Home view
                loadView('/views/Home');
                break;
            case 'Contact':
                // Load Contact view
                loadView('/views/Contact');
                break;
            // Add more cases as needed
            default:
                // Load a default view or show a 404 page
                loadView('/views/404');
                break;
        }
    }

    function loadView(view) {
        // Logic to load the view content
        console.log(`Loading view: ${view}`);
        // You can use AJAX or fetch to load the view content dynamically
    }
});