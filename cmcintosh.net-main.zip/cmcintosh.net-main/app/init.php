<?php
//ALL FILE PATHS RELATIVE TO:: 
require_once("app/core/File.php");
require_once("app/core/Dir.php");
require_once("app/core/Document.php");
require_once("app/core/Template.php");
require_once("app/core/Layout.php");
require_once ("app/controllers/Router.php");
?>