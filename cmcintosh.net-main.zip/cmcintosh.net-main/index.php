<script>
  window.location.href = "public/index.php";
</script>