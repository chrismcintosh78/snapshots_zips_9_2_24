class Template {
    constructor(filePath) {
        this.filePath = filePath;
        this.templateContent = null;

        this.loadTemplate();
    }

    loadTemplate() {
        readDoc(this.filePath)
            .then(response => response.getXML())
            .then(xmlContent => {
                this.templateContent = this.parseXML(xmlContent);
                console.log('Template Loaded:', this.templateContent);
            })
            .catch(error => {
                console.error('Error loading template:', error);
            });
    }

    parseXML(xmlContent) {
        if (xmlContent) {
            // If the content is XML or HTML, parse it into a document object
            const parser = new DOMParser();
            return parser.parseFromString(xmlContent, "text/xml");
        }
        return null;
    }
}

function readDoc(path) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', path, true);

        xhr.onreadystatechange = () => {
            if (xhr.readyState === 4) {
                if (xhr.status >= 200 && xhr.status < 300) {
                    const response = new CustomResponse(xhr.responseText, xhr.responseXML, xhr.status, xhr.statusText, xhr.getResponseHeader('Content-Type'));
                    resolve(response);
                } else {
                    reject(new Error('Failed to load document: ' + xhr.statusText));
                }
            }
        };

        xhr.onerror = () => reject(new Error('Network Error'));

        xhr.send();
    });
}

class CustomResponse {
    constructor(text, xml, status, statusText, contentType) {
        this.textContent = text;
        this.xmlContent = xml;
        this.status = status;
        this.statusText = statusText;
        this.contentType = contentType;
    }

    text() {
        return new Promise((resolve) => {
            resolve(this.textContent);
        });
    }

    json() {
        return new Promise((resolve) => {
            resolve(JSON.parse(this.textContent));
        });
    }

    getXML() {
        return new Promise((resolve) => {
            resolve(this.xmlContent);
        });
    }
}

// Usage example:
const myTemplate = new Template('/path/to/template/file.html');
