<?php
set_include_path(get_include_path() . ":" . '/var/www/html/');
ini_set("display_errors", 1);
require_once ("app/init.php");

// Read the HTML file
$objFile = new File("../app/templates/card.html");
$objFile->read();
$strFileContents = $objFile->strFileContents;

// Initialize the Document object
$objDocument = new Document($strFileContents);
$strResourcePath = "../res";
// Process with Template
$objTemplate = new Template($objDocument, $strResourcePath);
$htmLogo = "<img ";


$objTemplate->compile();
print $objTemplate->output();
?>
<img src="" alt="Logo">