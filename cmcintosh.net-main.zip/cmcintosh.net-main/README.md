================
3.24.24 18:12
================
Installed google material icons

5/27
created a template class for boilerplate code
committed MVC programming pattern dir structure